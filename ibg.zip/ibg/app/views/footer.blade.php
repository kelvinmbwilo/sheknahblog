<div style="background-image: url(pattern/pattern191.png)">
    <div class="container" style="color: white">
        <div class="row">
            <div class="col-md-3">
                <ul class="nav nav-pills nav-stacked">
                    <li><a href="#"><i class="fa fa-home"></i> Home</a></li>
                    <li><a href="#"><i class="fa fa-rss"></i> About Us</a></li>
                    <li><a href="#"><i class="fa fa-envelope-o"></i> Contacts</a></li>
                </ul>
            </div>
            <div class="col-md-6">
                <h3 class="text-info">Suscribe for our news later</h3>
                <div class="form-group col-md-8 ">
                    <label for="exampleInputEmail1" class="text-center text-info">Email address</label>
                    <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email">
                    
                  </div>
                <div class="col-md-8"><button type="submit" class="btn btn-warning btn-sm">Submit</button></div>
            </div>
            <div class="col-md-3">
                <ul class="nav nav-pills nav-stacked">
                    <li><a href="#"><i class="fa fa-facebook-square text-info fa-3x"></i> Facebook</a></li>
                    <li><a href="#"><i class="fa fa-twitter-square fa-3x" style="color: #00C0F7"></i> Twitter</a></li>
                    <li><a href="#"><i class="fa fa-instagram fa-3x" style="color: #3D6B92"></i> Instagram</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
